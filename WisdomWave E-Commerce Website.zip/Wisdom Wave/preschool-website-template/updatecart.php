<?php
     include('config.php');
      // Check if the request is coming with the expected data
      if (isset($_POST['cartId']) ) {
        
        // Get the values
        $id = $_POST['cartId'];
        $qty=$_POST['qty'];
        // Start session
        session_start();

        // Retrieve email from the session
        $email = $_SESSION['user'];


        // // Prepare the SQL query
      //  $query = "delete from cart where bookid='$id' and email='$email'";
        $query = "update cart set quantity=$qty where id=$id and status='cart'";

        // // Execute the query
        $result = mysqli_query($con, $query);

        if ($result) {
            // Product added to the cart table successfully
            echo json_encode(['status' => 'success', 'message' =>      'Product updated to the cart.']);
        } else {
            // Error in the insert operation
            echo json_encode(['status' => 'error', 'message' => 'Failed to update product to the cart.']);
        }

        // Check if the insert was successful
       /* if ($result) {
            // Product added to the cart table successfully
            echo json_encode(['status' => 'success', 'message' =>      'Product added to the cart.']);
        } else {
            // Error in the insert operation
            echo json_encode(['status' => 'error', 'message' => 'Failed to add product to the cart.']);
        }
    } else {
        // Return an error message if data is missing
        echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
    }*/
      }
?>