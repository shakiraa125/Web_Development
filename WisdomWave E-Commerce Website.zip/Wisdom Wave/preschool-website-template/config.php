<?php
    $host = "localhost";
    $user = "root";                     
    $pass = "";                                  //Remember, there is NO password by default!
    $db = "wisdomwave";                                  //Your database name you want to connect to
    $port = 3306;
    $con = mysqli_connect($host, $user, $pass, $db,$port)or die(mysql_error());
    if (mysqli_connect_error())
{
 echo "connot connect";   
}
else{
    echo "connected";

}
?>