<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Big Cart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="Free HTML Templates" name="keywords" />
    <meta content="Free HTML Templates" name="description" />

    <!-- Favicon -->
    <!-- <link href="img/favicon.ico" rel="icon" /> -->

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap"
      rel="stylesheet"
    />

    <!-- Font Awesome -->
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
      rel="stylesheet"
    />

    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
      integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65"
      crossorigin="anonymous"
    />
   
  </head>

  <body>
  <?php
    session_start();
     include 'header1.php';
      include('config.php');
   
     // $order_master_id= $_SESSION['order_master_id'];
      
       $email=$_SESSION['user'];
    //echo $email;
     $sql="SELECT om.total_amount,om.delivery_status,om.date,od.quantity,b.booktitle,b.price,b.bookpics,b.class,b.syllabus FROM order_master om INNER JOIN  order_details od  ON om.order_master_id=od.order_master_id  INNER JOIN bookdetails b on b.bookno=od.product_id where om.email='$email'";
     //read data from mysql

 
    
          
          $q=mysqli_query($con,$sql);
          if ($q->num_rows >0)  
          { 
              while($row = $q->fetch_assoc()) { 
                ?>
                <?php
              
                $date=$row["date"];
                $booktitle=$row["booktitle"];

                $class=$row["class"];
                $syllabus=$row["syllabus"];
                $quantity=$row["quantity"];
                $price=$row["price"];
               // $total_amount=$row["total_amount"];
                $status=$row["delivery_status"];
                $image=$row["bookpics"]; 
               // $id=$row["bookno"];
                // $url=$row["product_image"];
                // $id=$row["product_id"];
             
            //  echo $order_master_id;
            $total_amount= $price* $quantity;
            ?>
           
            <!-- Order detailse condainer -->
            <div class="col-lg-9 col-md-9" style="margin-top: 74px;">
              <div style="width: 100%;" id="details-ctr">
                <div style="width: 100%;" class="details-ctr card shadow-0 border  mb-4 ">
                  <div class="card-body">

                    <!-- Order details -->
                    <div class="row">

                      <!-- Procuct image -->
                      <div class="col-md-2">
                        <a href="product-detail.html">
                          <img src="./admin/pages/bookpics/<?php echo $image; ?>"
                          class="img-fluid" alt="book image">
                        </a>
                      </div>

                      <!-- Product name -->
                      <div class="col-md-2 text-center d-flex justify-content-center align-items-center">
                        <p class="text-muted mb-0"><?php echo $booktitle;?></p>s
                      </div>
                       <!-- Product name -->
                       <div class="col-md-2 text-center d-flex justify-content-center align-items-center">
                        <p class="text-muted mb-0"><?php echo $class;?></p>
                      </div>
                       <!-- Product name -->
                       <div class="col-md-2 text-center d-flex justify-content-center align-items-center">
                        <p class="text-muted mb-0"><?php echo $syllabus;?></p>
                      </div>

                      <!-- Product price -->
                      <div class="col-md-2 text-center d-flex justify-content-center align-items-center">
                        <p class="text-muted mb-0 small">price :<?php echo $price;?></p>
                      </div>

                      <!-- Ordered quantity -->
                      <div class="col-md-2 text-center d-flex justify-content-center align-items-center">
                        <p class="text-muted mb-0 small">Qty: <?php echo $quantity;?></p>
                      </div>

                      <!-- Total price -->
                      <div class="col-md-2 text-center d-flex justify-content-center align-items-center">
                        <p class="text-muted mb-0 small">Total Price:<?php echo $total_amount;?> </p>
                      </div>
                    </div>
               
          
            
                    <!-- /Order details end -->
             

                    <hr class="mb-4" style="background-color: #e0e0e0; opacity: 1;">

                    <!-- Track order section -->
                    <div class="row d-flex align-items-center">
                      <div class="col-md-2">
                        <p class="text-muted mb-0 small">delivery status</p>
                      </div>

                      <div class="col-md-10">

                        <!-- tracker bar -->
                      
                          <div class="progress-bar" role="progressbar"
                            style="width: 20%; border-radius: 16px; background-color: rgb(255, 230, 0);" aria-valuenow="65"
                            aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                        <!-- /tracker bar end -->

                        <!-- delivery status -->
                        <div class="d-flex justify-content-around mb-1">
                          <p class="text-muted mt-1 mb-0 small ms-xl-5"><?php echo $status?></p>
                          
                        </div>
                        <!-- delivery status end -->
                          <!-- delivery date -->
                          <div class="d-flex justify-content-around mb-1">
                          <p class="text-muted mt-1 mb-0 small ms-xl-5"><?php echo $date?></p>
                          
                        </div>
                        <!-- delivery date end -->
                      </div>
                    </div>
                    <!-- /Track order section end -->
                  </div>
                </div>
              </div>
            </div>
            <!-- /Order detailse condainer end -->
                
          <!-- </div>
      </div> -->
              <?php
                }}
               ?>
  
    <!-- /Admin main condainer end -->    
    <style>
      .hide {
        display: none;
      }

      .bg-coloer-t {
        background-color: rgb(254, 221, 55) !important;
      }

      .text-t-color {
        color:  rgb(254,93,55) !important;
      }
    </style>
  </body>
</html>
