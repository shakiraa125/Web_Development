<!DOCTYPE html>
<html lang="en">

<head>
	<title>Vegefoods - Free Bootstrap 4 Template by Colorlib</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/ionicons.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">


	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css">
</head>

<body class="goto-here">


	<?php
	session_start();
	require('config.php');
	if (isset($_SESSION['user']) && isset($_SESSION['totalcost'])) {

		$email = $_SESSION['user'];
		$total_amount = $_SESSION['totalcost'];
		echo $total_amount;
	} else {
		
		header('Location: kerala.php');
		echo'hai';
	}
	
	$allstates = array(
		"Andhra Pradesh" => "AP",
		"Arunachal Pradesh" => "AR",
		"Assam" => "AS",
		"Bihar" => "BR",
		"Chhattisgarh" => "CG",
		"Goa" => "GA",
		"Gujarat" => "GJ",
		"Haryana" => "HR",
		"Himachal Pradesh" => "HP",
		"Jharkhand" => "JH",
		"Karnataka" => "KA",
		"Kerala" => "KL",
		"Madhya Pradesh" => "MP",
		"Maharashtra" => "MH",
		"Manipur" => "MN",
		"Meghalaya" => "ML",
		"Mizoram" => "MZ",
		"Nagaland" => "NL",
		"Odisha" => "OD",
		"Punjab" => "PB",
		"Rajasthan" => "RJ",
		"Sikkim" => "SK",
		"Tamil Nadu" => "TN",
		"Telangana" => "TG",
		"Tripura" => "TR",
		"Uttar Pradesh" => "UP",
		"Uttarakhand" => "UK",
		"West Bengal" => "WB",
		"Andaman and Nicobar Islands" => "AN",
		"Chandigarh" => "CH",
		"Dadra and Nagar Haveli and Daman and Diu" => "DN",
		"Delhi" => "DL",
		"Lakshadweep" => "LD",
		"Puducherry" => "PY"
	);
	$q = mysqli_query($con, "select * from address ");

	include('header1.php');
	?>
	<div class="container">
		<div class="row no-gutters slider-text align-items-left justify-content-left">
			<div class="col-md-9 ftco-animate text-left">
				<p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home</a></span> <span><a href="">Checkout</a></span></p>
				<h1 class="mb-0 bread">Checkout</h1>
			</div>
		</div>
	</div>

	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-xl-7 ftco-animate">
					<form action="#" method="post" class="billing-form">
						<h3 class="mb-4 billing-heading">Billing Details</h3>
						<?php
						if ($q->num_rows > 0) {

							while ($row = $q->fetch_assoc()) {

								
								$email =  $_SESSION['user'];
								$state = $row["state"];
								$city = $row["city"];
								$postcode = $row["pincode"];
								$phone = $row["phoneno"];
								$street = $row["street"];
								$home = $row["home"];
								$district = $row["district"];
								$country = $row["country"];
								//$email = $row["email"];
								//$address = $row["address"];

							}
						?>

								<div class="row align-items-end">
									<div class="col-md-12">
										<div class="form-group">
											<label for="firstname">email</label>
											<input type="text" value="<?php echo $email ?>" name="name" class="form-control" placeholder="">
										</div>
									</div>

									<div class="w-100"></div>
									<div class="col-md-12">
										<div class="form-group">
											<label for="country">State</label>
											<div class="select-wrap">
												<div class="icon"><span class="ion-ios-arrow-down"></span></div>
												<select name="state" id="state" class="form-control">


													<?php
													foreach ($allstates as $value => $label) {
														echo "<option value=\"$label\"";
														echo $label == $state ? " selected" : "";
														echo ">$value</option>";
														echo "<script>console.log($value)</script>";
													}

													?>

												</select>
											</div>
										</div>
									</div>
									<div class="w-100"></div>
									<div class="col-md-12">
										<div class="form-group">
											<label for="streetaddress">home</label>
											<input type="text" name="home" value="<?php echo $home ?>" class="form-control" placeholder="House number and street name">
										</div>
									</div>

								    <div class="w-100"></div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="towncity">City</label>
											<input type="text" name="city" value="<?php echo $city ?>" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="postcodezip">Pincode*</label>
											<input type="number" name="postcode" value="<?php echo $postcode ?>" class="form-control" placeholder="">
										</div>
									</div>
									<div class="w-100"></div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="phone">Phone</label>
											<input type="number" name="phone" value="<?php echo $phone ?>" class="form-control" placeholder="">
										</div>
									</div>
									<div class="w-100"></div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="towncity">district</label>
											<input type="text" name="district" value="<?php echo $district ?>" class="form-control" placeholder="">
										</div>
									</div>
									<div class="w-100"></div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="towncity">country</label>
											<input type="text" name="country" value="<?php echo $country ?>" class="form-control" placeholder="">
										</div>
									</div>
									<div class="w-100"></div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="towncity">street</label>
											<input type="text" name="street" value="<?php echo $street ?>" class="form-control" placeholder="">
										</div>
									</div>
									
									
							<?php
							}
						
							?>
							<div class="w-100"></div>
							<button type="submit">Update</button>
								</div>
					</form><!-- END -->
				</div>
				<div class="col-xl-5">
					<div class="row mt-5 pt-3">
						<div class="col-md-12 d-flex mb-5">
							<div class="cart-detail cart-total p-3 p-md-4">
								<h3 class="billing-heading mb-4">Cart Total</h3>
								<p class="d-flex">
									<span>Subtotal</span>
									<span><?php
									echo $total_amount;
									?></span>
								</p>
								
								
								<hr>
								<p class="d-flex total-price">
									<span>Total</span>
									<span><?php
									echo $total_amount;
									?></span>
								</p>
							</div>
						</div>
						<div class="col-md-12">
							<div class="cart-detail p-3 p-md-4">
								<form action="checkout.php" method="post">
									<h3 class="billing-heading mb-4">Payment Method</h3>
									<div class="form-group">
										<div class="col-md-12">
											<div class="radio">
												<label><input type="radio" name="pay_mode" value="bank" class="mr-2"> Direct Bank Tranfer</label>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-12">
											<div class="radio">
												<label><input type="radio" name="pay_mode" id="pay_mode" value="cod" class="mr-2"> Cash on Delivery</label>
											</div>
										</div>
									</div>

									<div class="form-group">
										<div class="col-md-12">
											<div class="checkbox">
												<label><input type="checkbox" value="" class="mr-2"> I have read and accept the terms and conditions</label>
											</div>
										</div>
									</div>
									<button class="btn btn-primary py-3 px-4" type="submit" id="place" name="place">Place an order</button>
								</form>
							</div>
						</div>
					</div>
				</div> <!-- .col-md-8 -->
			</div>
		</div>
	</section> <!-- .section -->


	<?php

	include('footer.php');
	?>


	<!-- loader -->
	<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
			<circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
			<circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" />
		</svg></div>


	<script src="js/jquery.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
	<script src="js/google-map.js"></script>
	<script src="js/main.js"></script>

	<script>
		$(document).ready(function() {

			var quantitiy = 0;
			$('.quantity-right-plus').click(function(e) {

				// Stop acting like a button
				e.preventDefault();
				// Get the field name
				var quantity = parseInt($('#quantity').val());

				// If is not undefined

				$('#quantity').val(quantity + 1);


				// Increment

			});

			$('.quantity-left-minus').click(function(e) {
				// Stop acting like a button
				e.preventDefault();
				// Get the field name
				var quantity = parseInt($('#quantity').val());

				// If is not undefined

				// Increment
				if (quantity > 0) {
					$('#quantity').val(quantity - 1);
				}
			});

		});
	</script>

</body>
<?php

//updating billing_details table if any of the field changes and click sava button
if (isset($_POST['name']) || isset($_POST['state']) || isset($_POST['address']) || isset($_POST['city']) || isset($_POST['phone']) || isset($_POST['email']) || isset($_POST['postcode'])) {
	//$name = $_POST['name'];
	$state = $_POST['state'];
	$city = $_POST['city'];
	$postcode = $_POST['postcode'];
	$phone = $_POST['phone'];
	session_start();
	$email = $_SESSION['user'];
	$home = $_POST['home'];
	$q = mysqli_query($con, "UPDATE address
	SET  
		email = '$email', 
		state = '$state', 
		city = '$city', 
		pintcode = '$postcode', 
		phone = '$phone', 
		email = '$email', 
		home = '$home'
	WHERE email='$email'");
}

//saving data to order_master table

if (isset($_POST['place'])) {
	//echo 'hello';
	$email=$_SESSION['user'];
	$pay_mode = $_POST['pay_mode'];
	if(isset($_SESSION['totalcost'])){
		$total_amount = $_SESSION['totalcost'];
	}else{
		echo 'hai';
		header('Location: kerala.php');
		echo "<script>location.href = 'kerala.php';</script>";
	}
	
	$date = date('Y-m-d H:i:s');
	$r = mysqli_query($con, "insert into order_master (email,date,pay_mode,total_amount,admin_status,delivery_status) values ('$email','$date','$pay_mode',$total_amount,'ordered','pending')");

	//fetching the order_master id S

	$s = mysqli_query($con, "select order_master_id from order_master where date='$date'");
	if ($s) {
		while ($id = mysqli_fetch_assoc($s)) {
			//echo $id['order_master_id'];
		
			if ($id) {
				$order_master_id = $id['order_master_id'];
			}
		}
	
	}

	//getting product id from cart
	$t = mysqli_query($con, "select bookid from cart where email='$email' and status='cart'");
	if ($t) {
		
	
		$product_ids = array();
		while ($row = mysqli_fetch_assoc($t)) 
		{
			//echo "hello";
			$product_ids[] = $row['bookid'];
			//echo $row['bookid'];
			
		}
		
		
	


		foreach ($product_ids as $product_id) {
			
			//chanign status to out to all products in the cart
			$u = mysqli_query($con, "update cart set status='out' where email='$email' and bookid=$product_id");
			
			//getting quantity from cart_details
			$v = mysqli_query($con, "select quantity from cart where bookid=$product_id and email='$email'");
			if ($v) {
				echo "hello";
				
				
				while ($row = mysqli_fetch_assoc($v)) {
					
					//echo "hello";
					$quantity = $row['quantity'];

					//echo $order_master_id;
					//echo $product_id;
					//echo $quantity;
					//echo $email;
					//$w = mysqli_query($con, "insert into order_details (order_master_id,product_id,quantity,seller_email) values (0,0,0,'ll')");

					$w = mysqli_query($con, "insert into order_details (order_master_id,product_id,quantity,seller_email) values ($order_master_id,$product_id,$quantity,'$email')");

				}
				//$y=mysqli_query($con,"select email from bookdetails where bookno='$product_id'");
				//$seller_details=mysqli_fetch_assoc($y);
				//$seller_username=$seller_details['email'];
				

				//updating out stock in stock details table
				$x = mysqli_query($con, "insert into  stock (product_id,out_stock,in_stock) values($product_id,$quantity,0)");
				unset($_SESSION['totalcost']);
				echo "<script>location.href = 'user_order_details.php';</script>";	

			}
			}
			}		}

?>

</html>