<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>WisdomWave-reusable textbook selling system</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@600&family=Lobster+Two:wght@700&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none; z-index: 10000;" id="mySidebar">
            <button class="w3-bar-item w3-button w3-large" onclick="w3_close()">Close &times;</button>
            <a href="index.php" class="w3-bar-item w3-button"> Home</a>
            <a href="userprofile.php" class="w3-bar-item w3-button">Profile</a>
            <a href="user_order_details.php" class="w3-bar-item w3-button">orders</a>
            <a href="userlogin.php" class="w3-bar-item w3-button">Login </a> 
            <a href="register.php" class="w3-bar-item w3-button">Register</a>
            <a href="userlogin.php" class="w3-bar-item w3-button">Logout</a>
            <a href="userlogin.php" class="w3-bar-item w3-button">Sell Book</a>
            <a href="about.php" class="w3-bar-item w3-button">About us</a>
            <a href="contact.php" class="w3-bar-item w3-button">Contact us</a>
        </div>


        <div id="main">

            <div class="w3-teal">
                <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;</button>

            </div>
        </div>

        <script>
            function w3_open() {
                document.getElementById("main").style.marginLeft = "25%";
                document.getElementById("mySidebar").style.width = "25%";
                document.getElementById("mySidebar").style.display = "block";
                document.getElementById("openNav").style.display = 'none';
            }
            function w3_close() {
                document.getElementById("main").style.marginLeft = "0%";
                document.getElementById("mySidebar").style.display = "none";
                document.getElementById("openNav").style.display = "inline-block";
            }
        </script>

        <!-- sidebar-->

        <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top px-4 px-lg-5 py-lg-0">
            <a href="index.html" class="navbar-brand">
                <h1 class="m-0 text-primary"><i class="fa fa-book-reader me-3"></i>WisdomWave</h1>
            </a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav mx-auto">
                    <a href="index.php" class="nav-item nav-link">Home</a>
                    <a href="about.php" class="nav-item nav-link active">About Us</a>
                    <a href="contact.php" class="nav-item nav-link">Contact Us</a>
                </div>
             
            </div>
        </nav>
        <!-- Navbar End -->


        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">About Us</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>  <li class="breadcrumb-item text-white active" aria-current="page">About Us</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->


        <!-- About Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                        <h1 class="mb-4">Learn More About Our Work And Facilities</h1>
                        <p >The Secondhand Book Selling System is a web-based platform designed to facilitate the buying and selling of secondhand books. This system provides a user-friendly interface for both book sellers and buyers, aiming to connect individuals interested in trading books efficiently. Below are the key features and functionalities of the system</p>
                        <p>We providing All kerala ,CBSE,ICSE syllabus and Libraries in affordable prices</p>
                        <div class="row g-4 align-items-center">
                            <div class="col-sm-6">
                                <a class="btn btn-primary rounded-pill py-3 px-5" href="learnmore.php">Read More</a>
                            </div>
                            <div class="col-sm-6">
                                <div class="d-flex align-items-center">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 about-img wow fadeInUp" data-wow-delay="0.5s">
                        <div class="row">
                            <div class="col-12 text-center">
                                <img class="img-fluid w-75 rounded-circle bg-light p-3" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTRhmmNKVyP3cxxS-qWGRCf4duhqTn2wztzFg&usqp=CAU" alt="">
                                
                            </div>
                            <div class="col-6 text-start" style="margin-top: -150px;">
                                <img class="img-fluid w-100 rounded-circle bg-light p-3" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRucQCV53gQPpq963WyeCr2OQv1tTllO2ssSw&usqp=CAU" alt="">
                            </div>
                            <div class="col-6 text-end" style="margin-top: -150px;">
                                <img class="img-fluid w-100 rounded-circle bg-light p-3" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFRUXGBgXGBgYFxYXGBgXFRUXGBcVFRcYHSggGBolHRcVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGy0lHyUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAJkBSQMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAEBQIDBgEAB//EAEQQAAIABAQCBwUECAQGAwAAAAECAAMEEQUSITFBUQYTImFxgZEyUqGxwTNCgtEUI2JykrLh8BVTosIHFjRzg/FDY9L/xAAaAQADAQEBAQAAAAAAAAAAAAACAwQBAAUG/8QAMxEAAgIBAwEGBQQBBAMAAAAAAQIAEQMSITFBBBMiUWGRcYGhsfAywdHhQhQj4vEFUpL/2gAMAwEAAhEDEQA/ANZP6agDaAZ3TYsPs7iGdd0WlGW1hw0jN01IMgBGu3ppEeQhFs3L8GNMhqoQ/TAj/wCICLJHSSZM9mUPjE5OHI6EEC4ES6MIt8pHskiAZ16CL2D6TKknTma/VgGLZlfNT2gB5RqHpVDXhfjVIpQm20cLKFvKczqGAiQYi53sOQi18RmDl6Qpk0sybMDA+zfSG82gmFTpaCOP1nOwU0RFdTjDX4ekGUNTPmeyfhAWG0yhiJm9412FyEQ2XjDRjXTcWc29ATJYtik6SQHbfujsqsqGUMGNjGh6TYSJtjYaRVRzElBUa0dpRFDMJxyHgczPTsVmrozGA6jH8v3zDLpOUZwV2jPYnhgy5rweBcLjxecoz+Gio5AMZrPnZRMZmynviMrHgLgEw8oCkykA02+UBV2BS+q6xR3nwheYIr1UDsza9mgb4ypF94GfpCdlJis0g4RROpVXhGBUuWHD4QY3Ssmm1nbXvi/DJs95mRiwHOAzNy5I11FMl9kjeCKqcd10kznS20WYpRTZYvmJEZeorpmewUx9HxeVdbxlqynUNoPhEuvTYlHZwr0GiqXiJuAdI5i+KGXawveKq/CZ0xroumh9ItxPBp0xVAXbeGAJsb+U4VrII2i+qxZuyLbmB8bqHVQRxEHtgE1woykEWh3V9Hc0m1u0BBjIi1FdqWsp08VM/gUnOoZo2EvB1aWSBraE3R6jmS1KzFtbbWNTSTxlIgHbxGcxGha5mGweoeVVksLhQbeoEanD6MT6ibPN8q9iWNLFuLd4EVDD5aM86ZqMpAAGpJOwhjLpXYJ1mWTKBAWWurNYX7TDSDBDb8bVDDUm35/MInYYAQA13bcnTQd/jGb6bFmeXTAaKM7+f92hxieOZZ4lIAW3b9mWBfWEdPjKiTNqZgs01yF43Cmw0PCMxYyG1Vca+YhQG9vz7RTjc5maTT5cqIcwFuS6nv3jWYHSZEuRYkQqwaSKmb15UBFAVbaXtqT6/KNQRYcABrfwhrDgeX3kORtR2mY6YYnkAkKbM47R5IfqdfKMk1LbIn4j3km4H8saFaRZ89phvvc6gi3IcRpBFBITresNycwVASoBb46DU+ULOQDieliRVpfLmC09HlAQDtfU7w4lUTgKAja7WHKJS6xldgS7uS18naygcAUW8FTsUErt9WWmAaA37ItxzHU+EJ0Ox4/POUHtBXgCXY7JMuQEuobLsWA8TrzJ/wBMKuimGOgaY4HZBI7S7m/fyB9YHarqauZ9mwUAHTq7ZRzzbDxhxKlhZZQq4U6lgkrtbdlBaxGm/fBjSgKnr+cyNu9IHH9mJZWHTTOLEDb3luSx4axoerb3D6RkmxyVKnkBcyhr6oFY2/dAtEv+YpfI/wAUz847MjO11M700ASPz5z6rJl2UrvGEmSiHdeTH4w9m9LkGwJhV/zUjPlWXdj4RuSmWSdnXIHBAuew6YQ5BBt4RHDpTLPYhTYnlAj9L2zMok6r3/0gOo6azFOsrL43jO5JFQcwZn1AVvPos0XAiupprqR3RgcP6Vz5z5FAHlB9Xic9CAz2vHKShKNyYL4S4BEaYZhjS5l7i0H104qbBSbxlmr52hLG0Ef43M20jrNTWQk2Z6uoHYllW0MMGlTFYZh8YSzsfcaFgPKK2x9vf+EMVnC1UE4bN3Ndjsl3SyMAYzqYRNPtODFSYi7C+cxOS0xzYMYRkzDSQ3EYmE9JbPwMsNXEQnYFLIszxeMNmkbn4xWuCOyk31EKxshICmMyKSBqPAqVihkouVZmnjBeF1MoqZV7jWMxj8lpOUjjoYIwCWwmBjsfrD2Xw6iYpK5Ea1E6jQkMQCIpavojyPkYz/TGntOuONo7Q011GmsPXACgbeefm/8ALnHk7smO5lRTEggbd0TGJywbjTlGfSmbrSh0Frx2ZRaFb63tGMmmhct7BlHbNVcrNZ/zECtiLwN/j2ZsoSA6bo4JMkzJzaWv4RXQFAQy6gQlwout5RjAYx5LxEruAIhMxbLxWF9dKaoBYdmwtGEqjMz5c5teGYsGsXcXk8JqpvZuO2O6wVR4i0xSQRYd0fP6tLqNdR3xrsJASWMvG3xjMyDGB6zkGttMIm11+OvhAcyrIYC51hpOw5QFmcBFNeUd5YQXa8Cumt+YRB1UBDKOsEuVecCbtZOJ9IWY10jmTCiyZTC2gLaedodVmVbMR9mLKObEaQvx2QEWUw9rcke8R+ZgUIueiqUAPz4RFhlV1EqfMmjM80lFO99wNDwgbpOksCTTIdURQQD95tTcGNJjsuTmkK+iS+2bbXAAF+XExj6gBq6ZMBzDca332+EW4WFFuDz6eQnm5gSfT6zd9HpQSSq7WET6QTG6hwu7act9/heI0kzsAX4coTdK6yYuRUJ1uTYA8gBr5wkWeJ2FbyCCUlDOSU1g2q3OYc9reQPrDWmouqeRLuCyqXe9rXI134C/KBJNa7dVLGpdhfsreyna/gp25wmxMTOucm+ZgVW17m7aqPKOUFmo1LBegtNliWPJkEuU1gLFiNxf7yc1HHlC7DKWYRMee25svE25gcSdIzM+rNJNze1c6py56m4tbmIeyel8mamRP1bkWUlbBL2ugvodt7x2UMBS8Hr+bwMfgahzDpGIJKuhSwJOVSN2Fu3NI9rfQbR6ZjGvaYTJh3P3VHAKNoQ1WJLltMYaG2l7+AJ147fGAqWuBOWXLsOBYWue+9zCO7JHEvxgILPPvNRJxAOWDKGl27TEAgHgRfe0Z/8AxuV/lyv4FgPEKue3ZLe1cbarbQjfTxtxhJ+htyijDhQDx/eJzOxbwD4z65hOGqbgjUiM61D1U877xr0m5WJgDG1Urm0vExyeGx8JF2ZiuQEzOSUCVhJ2cXhpX0STkawsRCrGGyzZL99obSG0ZRx1gMnCuOa+xlGVdOZlHnfvFGESOrnoeem8PulVHmVW5EGMw1TkmIDuGHzja4uQ1PccoztBZcit+cxNbVM50kxBFWSinffwtFNLMAIJjPYnRvMtMXXLD6jp2eWCFN7co9bEo7n1kGWw1dIdiOHI4zCBpeC57QwlSHZLZWuIPk0c3JoLN3mEdnyaLRjNzWaYReKBpSjlB3R1/wBaQYiuGz2HbYRbQ4YyTA+ceEQ9pTVqAlOJxp3O8emtCNYxKncFiBxEL62llzDdnjkhklm4a/nE2LEyEHymkqbHnFPTGmzSiLbH6xbgtN+pW+4tBtTiUo3BF790DjEgPZWwixzYr1uJQNwYLj+H5irZbxXQYU2UHQfvEKPU6QW2NN7sXUNaZxymwsVNudmHygu9ZUoSTJ2BMmQOwh2E4ES+c5DpbR1PygbEOg86ZNLq0tQbHUnfyEGzaQcV+Edl9YnsTHX8RI9GuIEZh/kPrLMAODfGfcQyp6OTJkjqWZNRYnU8IW03/D/KgXrhpxC/1g+XjNQu+V/EZT6jT4QXJ6SD76MveNR8NfhDQ+E/3ArKvEqo+iiy1t1hP4R+cAzv+H1M752Z792UD5Q6bpLTj7zX5BHb4gWipulMngk4+CW/mIgv9pTYIEE96eQYD/yBRH2lY/iI+VoY0/RalQALL0HNmPzMDt0qXhImnx6sf7orbpS3Cn9ZgHyBjTlxVRI+s7u8kcrhMkLl6tbd4v8AOKBgVOGzCUAeYuPrCg9JZ52kyx4uzf7RETjlUf8AKH4GPzaBOfF+CaMWT8MOn9FpLHMC6m+be4v4GAcQ6KO9rTVIBv2gRoOGl4rfE6o//MB+6ifW8VNPnneomeWVf5VEKOXF/wCp+0pXJ2gf5/v+0RY50UqA0xnlmYnVgAyzc5h3b/CMBhoOdiQb5suu/Z0tH0HpRNeVTu/WzS2gF5j7k+PjGEwssQC1ySSxJ1JJO94pwvqQkccTHLGtX8TV01RZRFdXNDuF4hfdB4XilWPpw4wLMmfrGOS9lNtCe7yhbjaP7KBbHyH7x1Sz5SPLVTmKSydNNcvPh7RjLHGVExiVFydL3Oxve54wcas9bOYjUIQN9Lm3GEcnCGnkPcZQTmPLvPd9Y3Ci2dUpyisVrzGCYM9ZMaY2gAzOR7LKPvKeAgr9Fl5NsqcD95x+z7q9+5i+Xi6SkMkDKNLA+0595xwT9mKa9CB1h1PEe6e79nlHO7E+L5QezoDt0+/pFsynUG4AFvujl3czHncW03P96wOWLtcG1uPARxu7QceZ7/CCrzlgIXZRG0ipBDOdSAQ1jYk2sGB87RR+lLymfxmKFPYbwA9SIF60xgUQQiAm59eqik0E7Nb+/GEU+kdwbbARGbjMsG2YXi6ZMmZCwPZ7oXZ00Z4aEobER1+HvNlouzBhr4RrKDD0VQWPatGMfHSDsdN4byagPKzhrm3OBfEdIBG0dkzM7ausJxDAadnzltfGCJdSijIdVEZGbV1GrZeyDDSVWrNkXX2vrGth2F8CBqPnG4xGQgsqj4CK2xgLsotGNqKCYoz9Zfug2konYjMTYww4wN7nKmq/SPDj51Iy2io47MbZh5CFr4VlV1v3wRhdEAkC4VVsR2LCHMubEZp1LGF9Zi5XUlj5mGDHW0C4pQ5pR0gk7tjtKT2NkxanoN6SvC8aLuFtDypqAi3MZHDJBU3G4izFp006HaMfGpfSJJ3bVc0Zsy5wYbSRKEsM0Z/BKctLG8a+hpEaTlcQhf1FYptqlNBSIxNhpHZOH9VMzH2bEfK31hnIVFsBpHa2rYMAmUjLc3BPHbQiCdVA3gBjc7Mlm11P1ECTJjj7gbzsfrEDNA1ytLPNDmU+Ktw8IsmVosSBmPJfaP4WsfSJu9X/AC2+PHvxGafLeDvXoPbV07ypt6rcDzMWKVb2SD4G8Tpa6W5sDZuKsMrDyMRxHDZbD2QCd7XB+HHvhxQFbEwmjTWPz1r7wVtyOz66+kS6s8j/AAMfkLRKRRAC2Z7d7ue7iYk2Fym3lq3iAfnCdAhah1P57waZPRfadR4lF/mIgabi9Ou85fIhv5Lwy/wyUNkQfhUfSI9TJXig81ENGJOtzNY6XFJ6QSOBZvBX/wByiJUWPS3mCXldb3N2VQNPByfhB8+up13myx+IRjOlOK03tJOXMDwufkIMYUbZRCUi/FYE1tbVTlPYk514MH+ahDb1gb9JrDtKUDzv65h8oU9HulYZAbg+HPv740NBjYYnNCyNBpljjjNWtH3lAl1L3EyWpQ7r2Tp+ImFLYastsoQqFA3IbfwjXVlXMVc0uT1vcrqD6N+cZydNmTpmZlCbXW5JBAtY3A18Lw7HXSIZjW4EHmU4HibQtUjM2h1ZR7osT3eEaGdTFVaYxsAC3oIz1HXyTqcpYtexVhoqk8D4QbXUf2dqRvkIkeZdptvvWG9+N4c4fWiRLVDu1yL+yCRu3P6QFS1EtWLdkW10F/DVjFXSWsR8upJAA4cRfQAQVamCkbSxiClEfX1gFVIyv1puRe+u9+Rg6kxAzrcDsB7w9w93IwNSzhNXq2F+XOw2/EOHdAjS2ktca32PAjuhpGrY/qH2igSOP0xxVUYUXA7Pu+4eTQNLkM7WUePIDvPCGWGzetFxrwa97EcmPvDhHq7JKsqgsGIy30JPNxw7gYQGPHWU66GnrBKySqyhbUXGu19Dt3Qg68Rq8QCiQMxVmzPc3YHTTa1oxmde74w/D4hJcmWgPnNnPwqTkZs3a3/9R3CsZIlFHa/ARd0awcTy2Y7QJW4UZc1ltcCMsWVYzzblrYnLKlQlz4Xhdhta0sMLaGNP0Ww9btnQ7aaRTXdH3LvkUBeF4zWoJWd1i+nqJs0FVF+cLaZnlMyHSNl0dwt5DEtbXzjtdgMuZMMxmsT4CO7xQa6TLiugwg1CE32h3RUoNOPeQ/IxZQ9VIBCnfxMXSqsKDlXQxO7g88QkLA3E+JyWziymxHKOUNHMCHsnzh0a0tsv1i0JPO0s+n5x2u1C1GplZBtEowiYSDoIKbDLoVZvSPVkyauhDA8toV1U2YFLFWIhaeE7GVZe2ZcyhTUNp8IkJu1z4/lBEzqPdB8oyQx/uhxS1BmAWgsikG2iNLecKq8W6sWRIHkzK6a9paXFrnWwHix0EN6fo4TaZPbIo1Cj2m//ADFlZVvMPU04yqN+S97HiY7UB03gqln0HWKZ8qYgvUVIlk7JLGdj4t7I+MDYW9Yyl0mBrMRZhvbbXUDjwj2EUrfpDvnZnlzHVSSRbKSug2HHnvDGeJ8uYzyyHVjmZJhysTYA5ZnsnztDu6DrpBBbyO3sTsfe4vLkVaoGvPn6DcTwx+bL+3pmtxaV2wPw7wfSYtTztFmKT7p7LDusYGl45Kvlmq0luUxco8m2t5wZOwyROW5VHHA6H0YfSJ3xMhogqfX/AJb+zVBDqwtTY9P6l1RRKwsdu/W3hy8rQvm0M9RZJ7hdraMQL/dJ1v4kxAYLMl/YT3QcFb9Yn8LajyIjxxCpl/ayRMHvSTr/AAP9GhYUjge230P7E+kPXXWXSsLVh2qyoDcbsqelwRHhhMn71VPf8QPxVRHJeO0zGzPkb3ZgKN5Bt/K8Rm9IqVfvE+Ctb1tb4xKcDlt3f4Ub+gH2jBmccQSv6PSH+zapB/fOXzBa8K5fRBj7R9WdvmRDib0izA9TJcngSoy+ZBJ+ED9dXTP8tPw3HxN/hHq9ly5caaQ3/wBAX9VJ94DZHbk/X+4OvQuQurAfhQX+RMGUvR2Qlystr23bsg+XH0iKYNVN7VUyDlLyr8QBF8jAAlyXmTG5uxPPblvBZszsCGcn7ft9oC+E7GIsZoJY2yqf2LX8IUS60obB793HxhtjlJZTYWA5D8oQYJKR5mVDmPdwjMZBSyZQpIIqbDDsdZRD+hq0m9orZv79YEosIRVu9ieXARJ1W/Z08Ij1AG1jSFcbxN0lWqYsmX9UQe0vaHcCNx5xmJWDMFz3HstzHd9Y+p0wBtc687xa8tDuqN4qp+Yh69paosAKKAnx+jwpmHtDUgbE8YLxfB/1lsx/gPAeMfR6rCaZ/akqORXs6+A0jO4n0KDNnlTT4N+cNHaQTua+UMFaAqZWkwAs69objg4PyizHqAiWLFb3Y+3bdrC1+4Q5pcBqpDFu0QAbZSTc200BhH0hmVKhRaYbBRqL7DXcc4bjcs48QMHKQASL46QPDZE4I927KLmAzrbNuDod9IGweimzJwLNmOYXu4J5nc90XfpkwU73NizBfZUGwt3d5jnR+smgM1zorW0B4WHDvil7CsRXNfnzkiUWUb8EwzF5DhJYsdmY6i3aYngYzP6I3MeojTYrNmO9gBZVVbgAHQQq/RJvM/H8oBGob1HZEuuZ9ipKWRIuU0PmY9Nq04L8oCxFXVsosRzjQ4VhkmYga2vG/OJEQvJWYKL5iVsQ5KIqNTNbZT5CNzJwqUALIPSLxRryEM7jzMDvfITEU+DVE0XJK8r8fSL5fRVz7TxtHIUWgfr1+8QDG9yJ3fNM3J6IrxmMfCwhzQYMkoWtm8dTBkube5UecDTaxxuLRwxqOk3W5FS9lRdl9BE5c8HhaAmUnXNbwimgzdY1xccDf6Rj5UQ0SBOCEi6hNb1baNa8K6qmBUgC45WgnEqlQdUN/CCsOlNlBYZeQ4+fKMIB9ZtbTDjoSrzeIvqRwHfGhpaCRSi0te0PvtqfLlD2dNUDUgD5wjqqSTMByuynxuPQwl9th9ZQjM/6iaiXGMWJuLmJ4XORZagG1ySed7xVOwN76jN3gj6wTT4WhXK65QPvZh8rGFoVB8UfmAOOlPWKFcU8xjfrFmO7dkElQxzajja8PKSolzRdGDDu+vKFtXRrLmSyr517QJ5bWvFzYaL5l0J4jQ/CGO2Nz5fX3H8exk4Vgu/MZS6e2gAsfusMy+h28ohiNTJlgqssKqkm40F/esNzEsI6ztGYRlXY8Sx58NPyhbXSMzgE7gmFZXYVj1WIeFBZcjeGypEzLmkz0nLbZ7BvAzE08isCzcZCnLOlvLPMrmT+Jb2HjaKqOjAuNVPMEg+oi50mrxExeTaHyYfURSh7O3Nr8Nx+fKSZFyg+Gj8dj78TjyJE9dMkxT4MIilBIlakS0PM5QfU6mFddhDziDlSUQb5kLFj4kZYrl9EZW7uzHjc6Hya8c2PGNu8segP9D6wlLVuK+cYzsfpENjNBPJRc+XPyig9KUOkuW572BQfG3wvBFL0ekL7Mv5kflB8nDVX2ZYHkB8oysA6MfmB9r+8IE9a+sRSMSqZh1ZZa/8A1S2mH+JhYQ6p5SqhDTZ00k3uwUW8NBYQctN4D4xVVhUW5a3oPnAO6HhB9TO3PX2AH7TG9KqUOAFzlibAFgbnw1hj0bwMUsvMRmmNueA/ZXug2loe0Zz35KCdhztwJgHFcTtpf0gX7Q+Re7HHpK8PZwu/33hdRVm9jcR6RORdTvCVKy+4+MRE/WF93KyseviI2274WzMTYHskwN1w53gWonAmNXHvB2Eatjb23iVPjZ4xnZk/WPdZBnAszabCVjQO+3CDJderAA2tbYxhVnEcYvlVZhbdn8p1CbBqSQ+jIh56D6RZT4LTDaWPC5/OMvLrjzg6nxZhCijicV8pqJdBJXVZSfwi/qYszJ7o9BCKRi/OCP8AFhAEtA0GKVwarcjM1h46/CNzhcky5Si97af+4hlJgxaWyEE3vHrorjpPJZwesulT2vYXPyj02fMG4ELkmzJAP31Ol+I5EweSxAJttwjMvaUT9XPwmLiveQuW4+sJ8fw52S6O2cbW0h0gC/1iifi0pdPaPIRIO2DIdK7H1jlSiDzAMHepAVZ1gBxGt/HlDSYnM3hNU48xOWWvgPaJ8AIjJw6pm2Lt1a8jv/CPrCMy5ch0h/uBGAAbnaNJmJS03IPdE5FRNmaqgQH7zcu4bmIUmGyZOtsze82p8hsI9VYlbaDw4xgG7X+e8GtXAhLBU1c5m5m1/IcIX1eKE6L2RzhRXYmOJvCebUzJug7Kc/y5xpyM2w2EeuEDdoXjGLDYNrCP9NJ++RDampUB9kE8z2j/AEhlRUyNMAZFYd6i0CCAaje+CjaLaDFytrtcd8Nlqkmjfy0I+MRrMBpixBBlngUNvgbiEdRgTq1knKU943uPw8fWDYAcmYuRXat7+BjCqkymIz5AAb9ksp071aDMJp+sa8t/1antHl+yOBPp3xHDOhstgGmO7d1wt++w2ENpslZSiXKGVFvp8yTxMd+ldR4gO6tsOftIYnMUJlUWA+fMxjJn6yaEJNidO420I5G8OaytFjrCvID2r6wpHOrXGhQF0yM01Mg3H65ORNnHg3Hz1hlhuNyZpCklG2Kv2Tc8OR8o9Lr1YWYa8+BgSow9H1AB/vgYrDK36h8xt9OPapK6UaB/PTrHs7qk9plH7zD5EwvqOklHL061b8lFz5Quo+ismYCzqTra1yRoL7HbeG9LgEhPZlILd1/nBAYh5n2H8yZtd1t9T/EHpukBmi8iQzLe2Z2SWPQkmJvOqzxkoO4PMP8AqyiGyU3dEpksDl9Y7UBwB9T99vpOF9T+0zdd1oW8yomHuUrLH+lb/GAcJoQxM6aosNUzF2Y2+8S7HysIYYmoLdo2A4Hj3WhbiuIrl0Phb5CEtmdvCvXnp9ql+LCoGoiX4tigto3l9LQhMpj2305DkO/viyil2/WPqeA4CKq+rLbWAG55+EEiVsvvKbkhOBGkdYiBKWcNh5kxyqa9+C/OGjHvUB8gUTs2cxKhNjx3trbQQFWTZiFArEkk7jfU20MSpa0I4BC2UE9ruF4sl4gpqJINwBlvYm23C/jDCpHTacHBofCdrZvVvlbU5QT3E8LRxZoOxBizpBWq85iSDe26qflAsnIx+5/qWMA2BMYQCTW0JV9YultFFeAgYgHRgAMynZbmBqOvzH2SNO60dosWIjvAI3VotDXtC+mqVbZgfP6QbLbaEstRgaEppF3WQKh11i3L3wsrCufS8MSXOHWS3up1sdx3EQ4l0yiPlFPVdSzLms2YHQ7EqDoRwvGoxvH5stZRVrHNZtLg9m+vwj3cuNrFHY8T54KoO4mknybH9kworaiZJIVAXzbAAtYeUcwLpEZ2ZHUXUXvz15cNLQ0es4CPH7ZiUMFfkfYy3DZFiJVw+om6v2B+0df4V+toMk4DKHtlnPL2V9Br8YK63iTFE6t5ROGRRQEbpJhksJLFkVVHcAPXnFFRX2hXUVo4mE9diu9ow5WbYRi4Y2rcTtxjP1mKEmw4xTIkzZ57IsvFjt5czDvDcFEvvJ3PGMGM8neGXRNpnqincrmN78vzhhJXQWHDjGlWjFtoslUSjhDArdYhstxHS0rEwykUuUgwyWWBHmEb3a8mL1mVT6Bpg92O4bh1ls4079z/AEhzLQADSKpsy0EcKDeN/wBS5XQOJCZOAG2kZvGq0uMiaX3PdF+OYqqi14Q0tHNntct1aHTMdz4Dl3wjI5c+kZiQKNRiyolKGtm2iHWRr5PQRLX65/QR6b0FW4yzjbjdbnysRDe6YQv9RjPWY9nhtguA1b9oJZTszMFPmNSfMRuafBadMtpKXW1mKgtpxueMG51HG0NXGF/Ufz5yfJnDigJnaSgnSyUdMw3DLe1++17fCDpeHzTwVfHX+/SGyzwdLxbaGqqEbG5KSesTvhJ4vf8Av++EK8cwiYZTLLYhj35b6jTTntGttHCojHw3uCRCx5NBup8hqMDnO9pj5TbYWMC1/RxkVW63MSbBctvjePo+LYShbrDv4wi7DOyHZO15d0SI+QEqdq+FT1MeRW8XTrMPXI6NLQkEu2WwvoOJiNdSBduEX4+ZhqpIVNTc6a2vz5bwdXYew1ZgOcWAaQInK51ERAoAiE5rjlHKiaL6QKJt2A4eMOAiBuaEuk1Ely9xawyjQa3NuGsUSUlNUe1YA8+/vETWgGYADQksTodEF9x3wJh2Fs79k3Ja0YCtckSsq2voYdjeEdoMpGtzrcfHbjC+jw6ZmFtdRsQYa9Is8oKouD3afCFmG4i4e51sCdVB2EapYrYIM7KFUm4Ni/WBdQ2pY7HibD5QHQI4RzY7cuYP9IMxnETZRYaKu2Ybi/PviEvELSG7I1Nt27u/xihAdPHWQOw1c8CA4dLcuBruOHfD4NNzIFLa3O3NjaAsEru3e21zu3AE84dy6wl1GUaKo3Y8L84XlJs7R/ZlFDeGUSTi2UsvoeHgI0P+En3h6H8oz1FTzetL9q3DU8R+V42X6N4+pjz8zAEVXylZU3MbNwiplFFeU2UsAWGo1I1JFxxO8OOltbZA1zo6r6paNHglSsyapk1AmBbkq1ie7kw3G94s6Qys6y1anltdy51Bva9t1HP4R6ZzuGF9Pl9/hPHoGZjoRiBM1l37FyeXs92vGNwJ/GM3hUhEclZQlXJvbLqBoPZJ03gyprAI8rt+XvM5PoB9Jd2dKQRjPq++FNViFoXz60k2GpOwG58oMouj8yZ2ppyLyHtH6LEy4ydzHkqgsxdMqnmNlQFidgNTDfDejV7NPN/2Af5j9BD2ioZcoWRQOZ4nxO5gqHqoEnfOTsu0rlylUWAAA2A4ROOAxMJHFgIicjt4g5sQDxgqTSk76Dnz8IEPZpdzN01uZTLQsbAQwkyQmu55/lHbhRYQHV1VuMMLBBZ5nBC0sqasCM9iuLW0FyToANSTyAgfEsSOy6k6ADUkngINweg6kibOF3PHcSxy8eZhHiynfiU6Vxj16RZS4FPmHO4F9wDqB5cTDmZgjkX6zX4QzbEJdrq1/CKJmIuR2Fiju8fWBqzHepXSVryuy/p+UN0nhxdDrGfrKR2GeY6r56iKaSqAbsTA1uIjCGUVvX1EHQHO3M0BkzDubRJaHmdYjR4oraNoYjMxUAkAXhQ7N2fYtbfGzAY5Aa4layXV7naGCTxzhHWYkW3so9TCuqxDKp1JhuMLi2TiCbfmayoxKWguW9IU1PSA/cW3efyjKSZxaxB15bwbKoZr8D5wffM3EauFFFtDGrmmE5mvodBtGXxGqIQMh7Waz/urzh3iUpqdAx1LG1oSYpMRE62wK5Tn8TtGoG11KRQxahx/Ez1V0ivVO0v3VW/xMVVdRMmHtsbQL0OnyZjPmAvckDkL6W8o2lZhYmL+rKnuPCKXpWoCRhrFmYqdS8RAczSHuK0HUDWcub3BrGfnTLgnvggdozELyCMEfLKBGhyMbg+8QII6LTWAzmxGp7WupNoV1uks+Cj4ExdTTCklRe1x/WFMLWp6OMgtbeUZYviazZhvcAaDZhp46xzD5MtlmG66gKLgr7RtwhJKudYcUAAQd738kW8CwoUJzAFYuxumQzD7O5++OGnEd0SrKFFkSxYa6+2veeX7QhbWNeYf73gvHrAqvuqB9PkBFKitI+JkTqCW39IZgGGKVY23FvaX7zARoaejRZjki2ttwdtNhCro7TjIO9l/0gsYYSPZY82+sRZWsn4y3Bir2jilmrlckGw2JOxsRsNIcf4kvufCEVDbI6sLq1h5gjWGPWLzESkXOyqus7RDJwGdSGbMmLpayuuq8db8Pu7mFGP4jMExRLnP2ZYGjtuSeR8I+yUX/TD/ALf0j4pi32rf391I99N8pB6f9TwNVpNTgudZCF3LsRe5JO+oGvlDaXgk+YMxGRf2tCfAfnFfRr26fwT+URssY2MeSFDlsrefEuy5WTTjXy5ivCKGXLUFBrxY6k+f5QwYwtwD7IeLfOGE/Ywtj5RRu95JSCLjaIGcOAvA+CfZHxPzMXnaJGyMY0IAakaukmOt0OWCcOp5hQZzrxgzD/ZgpNosxYFKhj1ijlP6YJJolU5iSx4X2HgIlPqhHqiAJsA76fCoqEq3uZGoqozuLYiRpeG1VtGUqvtV/fX5xMPE28qQULjzBJCyv1szWYdl3yA/7j8IZVGIswNhYW4wvo+MV4n7Ji1f00JI5t7MVUuKNKmkZc45QcMVqph7ICjuH1MC4TvD+TAa62EpVO8JLE7QCkwdibz5pa+4vDhaGQo/VywD7x3jkveOVcNDsVo8RTIiZLUb+cFrHCkZdddbRJsxifAeMWzYVQB2mOxbmAtJv3+EWScLLHtJ2eMMqCGixhO8DpEzzaaSLaAjhxgOb0jGyL5mFnST7YwsMIPaHOw2+EpXs6VZ3hOPVc2c8tBqTr3Qi6dP1dAVG5fKT37GNNR+2v7pjGf8Qf8Ao1/7rfMxX2Y26/GMzn/YCjoP5mJwXQ5lOV12POPomG4j+qWYxCMbjfQkco+dUu4jSYl/0kj94/WPS7Qm6+v8TzMLeEzRfpUstd5asefGFONdSroFA7Wp005CKsM2gPpR7cvwHzhATxVK8Z0nVCsUko4AX7z20N+S7Hzj1fTZbKvaCg3IhfL+1k/vf7jDmd9p6/OAYaTUsxOdF+dRUZVhDSSuWUO5Hb+I5RHsb3HhHpv2f/jX+aBuwI9qIEzdMmacNd2Hzi/G2JmnXkPgIhhH2y/vfQxLFPtm/f8ArFn+Xynn1an4zWYPKtLB5CY23IBR84skpYW4RLDfsv8Axv8AziCKf7seUzT1cQADQ7DqcsjG21/DUAj4qIW5pv8AlxrKX7KZ4fQwDHK1C552fIWc1tP/2Q==" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->


      


        <!-- Team Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Team Members</h1>
                    
                </div>
                <div class="row g-4">
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item position-relative">
                            <img class="img-fluid rounded-circle w-75" src="img/team-1.jpg" alt="">
                            <div class="team-text">
                                <h3>Adhila</h3>
                               
                                <div class="d-flex align-items-center">
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square btn-primary  mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square btn-primary  mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="team-item position-relative">
                            <img class="img-fluid rounded-circle w-75" src="img/team-3.jpg" alt="">
                            <div class="team-text">
                                <h3>Shakira</h3>
                                
                                <div class="d-flex align-items-center">
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square btn-primary  mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square btn-primary  mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="team-item position-relative">
                            <img class="img-fluid rounded-circle w-75" src="img/team-1.jpg" alt="">
                            <div class="team-text">
                                <h3>Hafseena</h3>
                            
                                <div class="d-flex align-items-center">
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square btn-primary  mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square btn-primary  mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item position-relative">
                            <img class="img-fluid rounded-circle w-75" src="img/team-3.jpg" alt="">
                            <div class="team-text">
                                <h3>Mehza</h3>
                                
                                <div class="d-flex align-items-center">
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square btn-primary  mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square btn-primary  mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Team End -->


        <!-- Footer Start -->
        <div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-lg-3 col-md-6">
                        <h3 class="text-white mb-4">Get In Touch</h3>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>123 Street, New York, USA</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+012 345 67890</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>info@example.com</p>
                        <div class="d-flex pt-2">
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h3 class="text-white mb-4">Quick Links</h3>
                        <a class="btn btn-link text-white-50" href="">About Us</a>
                        <a class="btn btn-link text-white-50" href="">Contact Us</a>
                        <a class="btn btn-link text-white-50" href="">Our Services</a>
                        <a class="btn btn-link text-white-50" href="">Privacy Policy</a>
                        <a class="btn btn-link text-white-50" href="">Terms & Condition</a>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h3 class="text-white mb-4">Photo Gallery</h3>
                        <div class="row g-2 pt-2">
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="img/classes-1.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="img/classes-2.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="img/classes-3.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="img/classes-4.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="img/classes-5.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="img/classes-6.jpg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h3 class="text-white mb-4">news letter</h3>
                        <div class="position-relative mx-auto" style="max-width: 400px;">
                            <input class="form-control bg-transparent w-100 py-3 ps-4 pe-5" type="text" placeholder="Your email">
                            <button type="button" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">SignUp</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            &copy; <a class="border-bottom" href="#">Your Site Name</a>, All Right Reserved. 
							
							<!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
							Designed By <a class="border-bottom" href="https://htmlcodex.com">HTML Codex</a>
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-menu">
                                <a href="">Home</a>
                                <a href="">Cookies</a>
                                <a href="">Help</a>
                                <a href="">FQAs</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
