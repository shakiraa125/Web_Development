<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Big Cart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="Free HTML Templates" name="keywords" />
    <meta content="Free HTML Templates" name="description" />

    <!-- Favicon -->
    <!-- <link href="img/favicon.ico" rel="icon" /> -->

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap"
      rel="stylesheet"
    />

    <!-- Font Awesome -->
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
      rel="stylesheet"
    />

    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
      integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65"
      crossorigin="anonymous"
    />
    <?php    
     include('config.php');
      session_start();

      $email = $_SESSION['user'];
      echo $email;
    
     $sql="SELECT * FROM cart c INNER JOIN bookdetails b ON c.bookid=b.bookno where c.status='cart' and c.email='$email'";
     //read data from mysql

     $q=mysqli_query($con,$sql);
   //  $grand=0;

     ?>
  </head>

  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
  <body>
    <!-- header -->
    <!-- Topbar Start -->
    <div class="container-fluid">
      <div class="row bg-secondary py-1 px-xl-5">
        <div class="col-lg-6 text-center text-lg-right">
          <div class="d-inline-flex align-items-center d-block d-lg-none">
            <a href="/user/showWishlist" class="btn px-0 ml-2">
              <i class="fas fa-heart text-dark"></i>
            </a>
            <a href="/user/cart" class="btn px-0 ml-2">
              <i class="fas fa-shopping-cart text-dark"></i>
            </a>
          </div>
        </div>
      </div>

      <div
        class="row align-items-center bg-light py-3 px-xl-5 d-none d-lg-flex"
      >
        <div class="col-lg-4">
          <a href="" class="text-decoration-none">
           
            <span class="h1 text-uppercase text-dark bg-wartext-warning px-2 ml-n1"
              >WisdomWave</span
            >
          </a>
        </div>
        <div class="col-lg-4 col-6 text-left"></div>
      </div>
    </div>
    <!-- Topbar End -->

    <!-- Navbar Start -->
    <div class="container-fluid bg-dark mb-30" style="margin-bottom: 20px;">
      <div class="row px-xl-5">
        <div class="col-lg-9">
          <nav
            class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-0"
          >
            <a href="" class="text-decoration-none d-block d-lg-none">
              <span class="h1 text-uppercase text-dark bg-light px-2">BIG</span>
              <span class="h1 text-uppercase text-light bg-primary px-2 ml-n1"
                >CART</span
              >
            </a>
            <button
              type="button"
              class="navbar-toggler"
              data-toggle="collapse"
              data-target="#navbarCollapse"
            >
              <span class="navbar-toggler-icon"></span>
            </button>
            <div
              class="collapse navbar-collapse justify-content-between"
              id="navbarCollapse"
            >
              <div class="navbar-nav mr-auto py-0">
                <a href="/" class="nav-item nav-link">Home</a>
                <a href="/showProducts" class="nav-item nav-link">Shop</a>
                <a href="/contact" class="nav-item nav-link">Contact</a>

                <div class="nav-item dropdown">
                  <a
                    href="#"
                    class="nav-link dropdown-toggle"
                    data-toggle="dropdown"
                  >
                    Pages <i class="fa fa-angle-down mt-1"></i>
                  </a>
                  <div class="dropdown-menu bg-primary rounded-0 border-0 m-0">
                    <a href="/user/cart" class="dropdown-item">
                      Shopping Cart
                    </a>
                  </div>
                </div>

                <a href="/user/myAccount" class="nav-item nav-link"
                  >My Account</a
                >
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>
    <!-- Navbar End -->
    <!-- /header -->

    <style>
      .hide {
        visibility: hidden;
      }
      @keyframes fadeIn {
        from {
          transform: translateX(250px);
          opacity: 0;
        }
        to {
          transform: translateX(0px);
          opacity: 1;
        }
      }
      @keyframes fedOut {
        from {
          transform: translateX(0px);
          opacity: 1;
        }
        to {
          transform: translateX(250px);
          opacity: 0;
        }
      }
      .animate {
        animation: fadeIn 500ms ease-out backwards;
      }
      .out-animate {
        animation: fedOut 500ms ease-in forwards;
      }
    </style>

    <div
      style="position: absolute; z-index: 100; width: 100%; text-align: center"
      class="hide alert alert-danger"
      role="alert"
      id="remove"
    >
      removed from cart
    </div>

    <!-- Cart Start -->
    <div class="container-fluid">
      <div class="row px-xl-5">
        <div class="col-lg-9 table-responsive mb-5">
          <!-- cart element table -->
          <table id="myTable"
            class="table table-light table-borderless table-hover text-center mb-0"
          >
            <thead class="thead-dark">
              <tr>
                <th>Images</th>
                <th>Product Name</th>
                <th>Syllabus</th>
                <th>Class</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
                <th></th>
                
              </tr>
            </thead>
            <tbody class="align-middle">
            <?php
                $i=0;
                $grand=0;
                if ($q->num_rows >0)  { 
                    while($row = $q->fetch_assoc()) { 
                        $i=$i+1;
                      ?>
                      <?php
                      // $name=$row["name"];
                      // $email=$row["email"];
                      $booktittle=$row["booktitle"] ?? "";
                      $class=$row["class"] ?? "";
                      $syllabus=$row["syllabus"] ?? "";
                      $price=$row["price"] ?? 0;
                      $image=$row["bookpics"] ?? ""; 
                      $quantity=$row["quantity"] ?? 0; 
                      $cartId=$row["id"];
                      $grand=$grand+$price;
                      
                      // $url=$row["product_image"];
                      // $id=$row["product_id"];
                    ?>
                    
                      <!-- cart table row -->
                      <tr>
                        <!-- table colemn for images -->
                        <td class="align-middle">
                          <img
                          src="./admin/pages/bookpics/<?php echo $image; ?>"
                            alt=""
                            style="width: 50px"
                          />
                        </td>
                        <!-- /table colemn for images -->

                        <!-- table colemn for product name -->
                        <td class="align-middle"><?php echo $booktittle ?></td>
                        <!-- /table colemn for product name -->
                        <!-- table colemn for product name -->
                        <td class="align-middle"><?php echo $syllabus ?></td>
                        <!-- /table colemn for product name -->

                        <!-- table colemn for product price -->
                        <td class="align-middle"><?php echo $class ?></td>
                        <!-- /table colemn for product price -->

                        <!-- table colemn for product price -->
                        <td class="align-middle"><?php echo $price ?></td>
                        <!-- /table colemn for product price -->

                        <!-- table colemn for quantity and quanity buttons -->
                        <td class="align-middle" >  
                          <div class="input-group quantity mx-auto" style="width: 100px">
                              <div class="input-group-btn">
                                <a
                                  class="btn btn-sm btn-warning btn-minus"
                                  id="dec"
                                  name="dec"
                                  onclick="decreaseValue(<?php echo $cartId; ?>, <?php echo $price ?>,<?php echo $i; ?>)"
                                >
                                  <i class="fa fa-minus"></i>
                                </a>
                              </div>
                  
                                            <input
                              type="text" readonly
                              id="<?php echo $cartId; ?>"
                              name="<?php echo $cartId; ?>"
                              class="form-control bg-secondary border-0 text-center form-control form-control-sm bg-secondary border-0 text-center"
                              value="1"
                              
                            />
                              
                            <div class="input-group-btn">
                              <a
                                class="btn btn-sm btn-warning btn-plus"
                                onclick="increaseValue(<?php echo $cartId ?>, <?php echo $price ?>,<?php echo $i; ?>)"
                                id="inc"
                              >
                                <i class="fa fa-plus"></i>
                              </a>
                            </div>

                             </div>
                        </td>
                        
                        <!-- <h6 echo $grand ?></h6>-->
                      
                        <!-- /table colemn for quantity and quantity buttons -->

                        <!-- table colemn for total quantity price -->
                        <td class="align-middle">

                          <input
                                  type="text" readonly
                                  id="<?php echo $i; ?>"
                                  name="<?php echo $i; ?>"
                                  style="width:250px"
                                  value="<?php echo $price ?>"
                                  
                                />
                                <input
                              id="cart"
                              name="cart"
                              type="hidden"
                              value="<?php
                            
                              echo $cartid ;
                              ?>
                        </td>
                            
                                <td class="align-middle">
                          <a
                            class="btn btn-sm btn-danger"
                            id="<?php echo $cartId ?>"
                            onclick="removeFromCart(<?php echo $cartId ?>)"
                          >
                            <i class="fa fa-times"></i>
                          </a>
                          <a id="relodMyCart" href="cart.php" hidden>remove recode</a>
                        </td>
                        <!-- /table colemsn for delet product from cart button -->
                      </tr>
        
                    <?php
                        }}
                         
                   ?>

                    </tbody>
                  </table>
              <!-- / cart table row -->
          
          <!-- /cart element table -->
 
          <h5 class="section-title position-relative text-uppercase mb-3">
            <span class="pr-3"> Cart Summary </span>
          </h5>
          <div class="bg-light p-30 mb-5">
              <form method="post"><div class="col-lg-3">
              <div class="border-bottom pb-2">
                  <div class="d-flex justify-content-between mb-3">
                    <h6>Subtotal</h6>
                    <h6 id="sub"><?php echo $grand ?></h6>
                  </div>
                  
                  <div class="d-flex justify-content-between">
                    <h6 class="font-weight-medium">Shipping</h6>
                    <h6 class="font-weight-medium">0</h6>
                  </div>
                </div>
                <div class="pt-2">
                  <div class="d-flex justify-content-between mt-2">
                    <h5>Total</h5>
                    <h6 id="grand"><?php
                    echo $grand ?></h6>
                    <input
                      
                      type="hidden"
                      value="<?php
                    
                      echo $grand ;
                      ?>"
                      id="cartPrice"
                      name="cartPrice"
                    />
                  </div>
                
                  <button
                  type="submit"
                  id="submit"
                  name="submit"
                  value="proceed"
                >
                proceed
                </button>
                    <!-- <a
                  href="checkout.php"
                    class="btn btn-block btn-warning font-weight-bold my-3 py-3"
                    id="proceed"
                  >
                    Proceed
                  </a>-->
                </div>
              </div>     

            </div> 
          </form>
      </div>
    </div>
    <!-- Cart End -->

    <!-- script of product quantity buttons -->
    <script>
    /*  function applyCoupon(cartPrice) {
        const code = document.getElementById("couponCodeInput").value;
        let TotalPrice = document.getElementById("cartPrice").value;
        console.log(TotalPrice);
        $.ajax({
          url: `/user/applyCoupon`,
          method: "post",
          data: {
            coupon: code,
            price: TotalPrice,
          },
          success: (response) => {
            console.log(response);
            document.getElementById("cartPriceShow").innerHTML = response.price;
            document.getElementById("couponDiscount").innerHTML =
              response.discount;

            // show error message if there is any message passed
            if (response.message) {
              document.getElementById("couponError").innerHTML =
                response.message;
              document.getElementById("couponError").classList.remove("hide");
              setTimeout(() => {
                document.getElementById("couponError").classList.add("hide");
              }, 3000);
            }
            // $("a").attr("href", `/user/checkout?cartPrice=${response.price}`);
            document.getElementById(
              "proceed"
            ).href = `/user/checkout?cartPrice=${response.price}&discount=${response.discount}`;
          },
        });
      }*/

      function increaseValue(id, price,i) {
        var value = parseInt(document.getElementById(id).value, 10);
        value = isNaN(value) ? 0 : value;
        value++;
        document.getElementById(id).value = value;

        // get cart price
        let cartPrice = document.getElementById("cartPrice").value;
      //   document.getElementById("total").value =
          Number(price) + Number(price);
       // document.getElementById("cartPriceShow").innerHTML =
          Number(cartPrice) + Number(price);

        // change the total price of that row
        let totalprice = value * price;
     //   alert(totalPrice);
        document.getElementById(i).value = totalprice;
	 
updateTotalPrice();
 updateFromCart(id,value);
        // send request
        $.ajax({
          url: `/user/addToCart/${id}`,
          method: "get",
        });
        document.getElementById("proceed").href = `/user/checkout?cartPrice=${
          document.getElementById("cartPriceShow").innerHTML
        }&discount=${document.getElementById("couponDiscount").innerHTML}`;
      }
function getColumnTextBoxValues(col) {
var total=0;
  var values = [];
  var inputs = document.querySelectorAll("#myTable tr td:nth-child(" + col + ") input[type='text']");
  inputs.forEach(function(input) {
    values.push(input.value);
    total +=parseInt(input.value);
  });
  
  return total;
}
function updateTotalPrice() {

 var columnValues = getColumnTextBoxValues(7); // Get values from Column 1
 

 document.getElementById("sub").innerHTML = columnValues.toFixed(2);
 document.getElementById("grand").innerHTML = columnValues.toFixed(2);
 document.getElementById("cartPrice").value = columnValues.toFixed(2);
}
      function decreaseValue(id, price,i) {
  var value = parseInt(document.getElementById(id).value, 10);

        value = isNaN(value) ? 0 : value;
        value < 1 ? (value = 1) : "";
        value--;

    
        if (value > 0) {
   
          document.getElementById(id).value = value;

          // get cart price
        //  let cartPrice = document.getElementById("cartPrice").value;
          //document.getElementById("cartPrice").value =
            Number(cartPrice) - Number(price);
          //document.getElementById("cartPriceShow").innerHTML =
            Number(cartPrice) - Number(price);

          // totoal price of product
//          let totalPrice = price * value;
  //        let idOfPrice = iD.slice(0, -1) + "p";
          // change the value
    //      document.getElementById(idOfPrice).innerHTML = totalPrice;
        let totalprice = value * price;
        
        document.getElementById(i).value = totalprice;

updateTotalPrice();
          $.ajax({
            url: `/user/decreaseQt/${iD}`,
            method: "get",
          });
          document.getElementById("proceed").href = `/user/checkout?cartPrice=${
            document.getElementById("cartPriceShow").innerHTML
          }&discount=${document.getElementById("couponDiscount").innerHTML}`;
        }
      }

      function removeFromCart(id) {
      
      
        console.log(`removeing from cart id:  ${id}`);
         
        let remove = document.querySelector("#remove");
        remove.classList.remove("hide");
        remove.classList.remove("out-animate");
        remove.classList.add("animate");
        $.ajax({
          
          
          url: `./removeFromCart.php`,
          method: "POST",
          data: {
            productId: id,
          },
          success: function(response) {
            console.log('successfully removed from the cart');
            console.log(response);
          },
          error: function(error) {
              console.log('error found --------------');
              console.error(error);
            
          }
        });
        setTimeout(() => {
          remove.classList.remove("animate");
          remove.classList.add("out-animate");
          document.getElementById("relodMyCart").click();
        }, 1000);
        setTimeout(() => {
          remove.classList.add("hide");
        }, 2000);
      }
      function updateFromCart(id,value) {
      
      
     //   console.log(`removeing from cart id:  ${id}`);
         
      //  let remove = document.querySelector("#remove");
        //remove.classList.remove("hide");
        //remove.classList.remove("out-animate");
        //remove.classList.add("animate");
        $.ajax({
          
          
          url: `./updatecart.php`,
          method: "POST",
          data: {
            cartId: id,
            qty:value,
          },
          success: function(response) {
            //console.log('successfully removed from the cart');
            console.log(response);
          },
          error: function(error) {
              console.log('error found --------------');
              console.error(error);
            
          }
        });
        setTimeout(() => {
          //remove.classList.remove("animate");
          //remove.classList.add("out-animate");
         // document.getElementById("relodMyCart").click();
        }, 1000);
        setTimeout(() => {
       //   remove.classList.add("hide");
        }, 2000);
      }

    </script>
    <!-- /script of product quantity buttons -->

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-secondary mt-5 pt-5">
      <div class="row px-xl-5 pt-5">
        <div class="col-lg-8 col-md-12">
          <div class="row">
            <div class="col-md-4 mb-5">
              <h5 class="text-secondary text-uppercase mb-4">Quick Shop</h5>
              <div class="d-flex flex-column justify-content-start">
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Home</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Our Shop</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Shop Detail</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Shopping Cart</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Checkout</a
                >
                <a class="text-secondary" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Contact Us</a
                >
              </div>
            </div>
            <div class="col-md-4 mb-5">
              <h5 class="text-secondary text-uppercase mb-4">My Account</h5>
              <div class="d-flex flex-column justify-content-start">
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Home</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Our Shop</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Shop Detail</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Shopping Cart</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Checkout</a
                >
                <a class="text-secondary" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Contact Us</a
                >
              </div>
            </div>
            <div class="col-md-4 mb-5">
              <h5 class="text-secondary text-uppercase mb-4">Newsletter</h5>
              <p>Duo stet tempor ipsum sit amet magna ipsum tempor est</p>
              <form action="">
                <div class="input-group">
                  <input
                    type="text"
                    class="form-control"
                    placeholder="Your Email Address"
                  />
                  <div class="input-group-append">
                    <button class="btn btn-warning">Sign Up</button>
                  </div>
                </div>
              </form>
              <h6 class="text-secondary text-uppercase mt-4 mb-3">Follow Us</h6>
              <div class="d-flex">
                <a
                  style="margin-right: 10px"
                  class="btn btn-warning btn-square mr-2"
                  href="#"
                  ><i class="fab fa-twitter"></i
                ></a>
                <a
                  style="margin-right: 10px"
                  class="btn btn-warning btn-square mr-2"
                  href="#"
                  ><i class="fab fa-facebook-f"></i
                ></a>
                <a
                  style="margin-right: 10px"
                  class="btn btn-warning btn-square mr-2"
                  href="#"
                  ><i class="fab fa-linkedin-in"></i
                ></a>
                <a
                  style="margin-right: 10px"
                  class="btn btn-warning btn-square"
                  href="#"
                  ><i class="fab fa-instagram"></i
                ></a>
              </div>
              <hr />
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer End -->
    <?php

    if (isset($_POST['submit'])) {
     
        
        $_SESSION['totalcost']=$_POST['grand'];
        echo $_POST['grand'];
      $_SESSION['totalcost']=$_POST['cartPrice'];
      //header('Location: checkout.php');
        echo "<script>location.href = 'checkout.php';</script>";
      }
    ?>
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="lib/easing/easing.min.js"></script> -->
    <!-- <script src="lib/owlcarousel/owl.carousel.min.js"></script> -->

    <!-- Contact Javascript File -->
    <!-- <script src="mail/jqBootstrapValidation.min.js"></script> -->
    <!-- <script src="mail/contact.js"></script> -->

    <!-- Template Javascript -->
    <!-- <script src="js/main.js"></script> -->

    <!-- Template Javascript -->
  </body>
</html>
