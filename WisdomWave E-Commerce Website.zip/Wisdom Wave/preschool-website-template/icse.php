<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Big Cart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="Free HTML Templates" name="keywords" />
    <meta content="Free HTML Templates" name="description" />

    <!-- Favicon -->
    <!-- <link href="img/favicon.ico" rel="icon" /> -->

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap"
      rel="stylesheet"
    />

    <!-- Font Awesome -->
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
      rel="stylesheet"
    />

    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
      integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65"
      crossorigin="anonymous"
    />
    <?php
     
             
     include('config.php');
     
      $sql="select * from bookdetails where syllabus='icse'";
      //read data from mysql
      $q = mysqli_query($con, $sql);
     ?>
     <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  </head>

  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
  <body>
    <!-- header -->
    <!-- Topbar Start -->
    <div class="container-fluid">
      <div class="row bg-secondary py-1 px-xl-5">
        <div class="col-lg-6 text-center text-lg-right">
          <div class="d-inline-flex align-items-center d-block d-lg-none">
            <a href="/user/showWishlist" class="btn px-0 ml-2">
              <i class="fas fa-heart text-dark"></i>
            </a>
            <a href="/user/cart" class="btn px-0 ml-2">
              <i class="fas fa-shopping-cart text-dark"></i>
            </a>
          </div>
        </div>
      </div>

      <div
        class="row align-items-center bg-light py-3 px-xl-5 d-none d-lg-flex"
      >
        <div class="col-lg-4">
          <a href="" class="text-decoration-none">
          
            <span
              class="h1 text-uppercase text-dark bg-wartext-warning px-2 ml-n1"
              style="color:red;">Wisdom Wave</span
            >
            
            <div style="padding-left:1100px;">
                     
                      <a href="cart.php"
                      class="btn btn-warning btn-outline-dark btn-square"
                    >
                      <i class="fa fa-shopping-cart"></i>
                    </a>

        </div>
        <div class="col-lg-4 col-6 text-left"></div>
      </div>
    </div>
    <!-- Topbar End -->

    <!-- Navbar Start -->
     
<!-- sidebar-->
<div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none; z-index: 10000;" id="mySidebar">
            <button class="w3-bar-item w3-button w3-large" onclick="w3_close()">Close &times;</button>
            <a href="index.php" class="w3-bar-item w3-button"> Home</a>
            <a href="userprofile.php" class="w3-bar-item w3-button">Profile</a>
            <a href="user_order_details.php" class="w3-bar-item w3-button">orders</a>
            <a href="userlogin.php" class="w3-bar-item w3-button">Login </a> 
            <a href="register.php" class="w3-bar-item w3-button">Register</a>
            <a href="userlogin.php" class="w3-bar-item w3-button">Logout</a>
            <a href="userlogin.php" class="w3-bar-item w3-button">Sell Book</a>
            <a href="about.php" class="w3-bar-item w3-button">About us</a>
            <a href="contact.php" class="w3-bar-item w3-button">Contact us</a>
        </div>


        <div id="main">

            <div class="w3-teal">
                <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;</button>

            </div>
        </div>

        <script>
            function w3_open() {
                document.getElementById("main").style.marginLeft = "25%";
                document.getElementById("mySidebar").style.width = "25%";
                document.getElementById("mySidebar").style.display = "block";
                document.getElementById("openNav").style.display = 'none';
            }
            function w3_close() {
                document.getElementById("main").style.marginLeft = "0%";
                document.getElementById("mySidebar").style.display = "none";
                document.getElementById("openNav").style.display = "inline-block";
            }
        </script>

        <!-- sidebar-->
    <div class="container-fluid bg-dark mb-30" style="margin-bottom: 20px">
    
      <div class="row px-xl-5">
        <div class="col-lg-9">
          <nav
            class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-0"
          >
            <a href="" class="text-decoration-none d-block d-lg-none">
              <span class="h1 text-uppercase text-dark bg-light px-2">BIG</span>
              <span class="h1 text-uppercase text-light bg-primary px-2 ml-n1"
                >CART</span
              >
            </a>
            <button
              type="button"
              class="navbar-toggler"
              data-toggle="collapse"
              data-target="#navbarCollapse"
            >
              <span class="navbar-toggler-icon"></span>
            </button>
            <div
              class="collapse navbar-collapse justify-content-between"
              id="navbarCollapse"
            >
            
              <div class="navbar-nav mr-auto py-0">
                
                <a href="index.php" class="nav-item nav-link">Home</a>
                < <a href="#" class="nav-item nav-link">icse</a>
                <a href="kerala.php" class="nav-item nav-link">kerala</a>
                <a href="cbse.php" class="nav-item nav-link">cbse</a> href="#" class="nav-item nav-link">Shop</a>
                <a href="contact.php" class="nav-item nav-link">Contact</a>

                <div class="nav-item dropdown">
                  <a
                    href="#"
                    class="nav-link dropdown-toggle"
                    data-toggle="dropdown"
                  >
                    Pages <i class="fa fa-angle-down mt-1"></i>
                  </a>
                  <div class="dropdown-menu bg-primary rounded-0 border-0 m-0">
                    <a href="/user/cart" class="dropdown-item">
                      Shopping Cart
                    </a>
                  </div>
                </div>

                <a href="/user/myAccount" class="nav-item nav-link"
                  >My Account</a
                >
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>
    <!-- Navbar End -->

    <style>
      .hide {
        visibility: hidden;
      }
      @keyframes fadeIn {
        from {
          transform: translateX(250px);
          opacity: 0;
        }
        to {
          transform: translateX(0px);
          opacity: 1;
        }
      }
      @keyframes fedOut {
        from {
          transform: translateX(0px);
          opacity: 1;
        }
        to {
          transform: translateX(250px);
          opacity: 0;
        }
      }
      .animate {
        animation: fadeIn 500ms ease-out backwards;
      }
      .out-animate {
        animation: fedOut 500ms ease-in forwards;
      }
    </style>
    <div
      style="position: absolute; z-index: 100; width: 100%; text-align: center"
      class="hide alert"
      role="alert"
      id="addedNotification"
      name="addedNotification"
    >
      product added to cart
    </div>

    <!-- Shop Start -->
    <div class="container-fluid">
      <div class="row px-xl-5">
        

        <!-- Shop Sidebar Start -->
        <div>
          <!-- filter by category -->
          <h4 class="section-title position-relative text-uppercase mb-3">
            <span class="pr-3">Products</span>
          </h4>
          <div>
        
       
          
         
            <div style="display: grid; grid-template-columns: auto auto auto auto auto;" class="">
           
              <?php
          
      
                if ($q->num_rows >0)  
                { 
                    while($row = $q->fetch_assoc()) 
                    { 
                      ?>
                      <?php
                    
                      
                      $booktitle=$row["booktitle"];
                      $class=$row["class"];
                      $price=$row["price"];
                      $syllabus=$row["syllabus"];
                      $image=$row["bookpics"]; 
                      $id=$row["bookno"];
                      // $url=$row["product_image"];
                      // $id=$row["product_id"];
                    ?>   
          

                    <div class="product-item bg-light mb-4" style="margin: 5px;">
                    
                      <div class="product-img position-relative overflow-hidden">
                        <img
                          style="max-height: 420px !important; margin-bottom: 10px"
                          class="img-fluid w-100 h-420"
                          src="./admin/pages/bookpics/<?php echo $image; ?>" alt=""/>
                        <div class="product-action" style="display: flex; justify-content: space-around;">
                          <div>
                            <a
                            class="btn btn-warning btn-outline-dark btn-square"
                            onclick="addToCart(<?php echo $id ?> , 1)"
                          >
                            <i class="fa fa-shopping-cart"></i>
                          </a>
                         
                          <a
                            class="btn btn-warning btn-outline-dark btn-square"
                            href="/detail/<%= product.id %>"
                            >info</a
                          >
                          </div>
                        </div>
                      </div>
                      <div class="text-center py-4">
                        <a class="h6 text-decoration-none text-truncate" 
                          ><?php echo $booktitle ?></a
                        >
                        <div
                          class="d-flex align-items-center justify-content-center mt-2"
                        >
                        
                          
                        </div>
                        <div
                          class="d-flex align-items-center justify-content-center mt-2"
                        >
                          <h5><?php echo $class ?></h5>
                          
                        
                        </div>
                        <div
                          class="d-flex align-items-center justify-content-center mt-2"
                        >
                          <h5><?php echo $syllabus ?></h5>
                          
                        
                        </div>
                        <div
                          class="d-flex align-items-center justify-content-center mt-2"
                        >
                          <h5><?php echo$price?></h5>
                          
                        
                        </div>
                        <div>
                          Quantity:1
                        </div>
                      <!--... <div
                          class="d-flex align-items-center justify-content-center mb-1"
                        >
                          <small class="fa fa-star text-warning mr-1"></small>
                          <small class="fa fa-star text-warning mr-1"></small>
                          <small class="fa fa-star text-warning mr-1"></small>
                          <small class="fa fa-star text-warning mr-1"></small>
                          <small class="fa fa-star text-warning mr-1"></small>
                          <small>(99)</small>
                        </div>--> 
                      </div>
                    
                    </div>

                <!-- Close php tag -->
                <?php
                  }} 
                ?>
             
              
              
            </div>
            
          </div>
         
         
      </div>
      
     
  
   
      </div>   
       
  
    <!-- Shop End -->

    <!-- cart update ajax -->
    <script>
      function addToWishlist(productId, user) {
        let addedNotification = document.querySelector("#addedNotification");
        if (user) {
          addedNotification.innerHTML = "product added to withlist!";
          addedNotification.classList.add("alert-success");
          $.ajax({
            url: `/user/addToWishlist/${productId}`,
          });
        } else {
          addedNotification.innerHTML = "your not logged in!";
          addedNotification.classList.add("alert-warning");
        }
        addedNotification.classList.remove("hide");
        addedNotification.classList.remove("out-animate");
        addedNotification.classList.add("animate");

        setTimeout(() => {
          addedNotification.classList.remove("animate");
          addedNotification.classList.add("out-animate");
        }, 1000);
        setTimeout(() => {
          addedNotification.classList.add("hide");
        }, 2000);
      }

      function addToCart(productId, user) {
        
        // console.log(user);
        console.log(productId);
        let addedNotification = document.querySelector("#addedNotification");
        if (user) {
          addedNotification.innerHTML = "product added to your cart!";
          addedNotification.classList.add("alert-success");
        } else {
          addedNotification.innerHTML = "your not logged in!";
          addedNotification.classList.add("alert-warning");
        }

        addedNotification.classList.remove("hide");
        addedNotification.classList.remove("out-animate");
        addedNotification.classList.add("animate");
        $.ajax({
          url: `./add-to-cart.php`,
          method: "POST",
          data: {
            productId: productId,
            userId: user
          },
          success: function(response) {
            // Handle the response from the server if needed
            console.log(response);
          },
          error: function(error) {
              // Handle errors if any
              console.error(error);
          }
        });
        setTimeout(() => {
          addedNotification.classList.remove("animate");
          addedNotification.classList.add("out-animate");
        }, 1000);
        setTimeout(() => {
          addedNotification.classList.add("hide");
        }, 2000);
      }
    </script>

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-secondary mt-5 pt-5">
      <div class="row px-xl-5 pt-5">
        <div class="col-lg-8 col-md-12">
          <div class="row">
            <div class="col-md-4 mb-5">
              <h5 class="text-secondary text-uppercase mb-4">Quick Shop</h5>
              <div class="d-flex flex-column justify-content-start">
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Home</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Our Shop</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Shop Detail</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Shopping Cart</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Checkout</a
                >
                <a class="text-secondary" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Contact Us</a
                >
              </div>
            </div>
            <div class="col-md-4 mb-5">
              <h5 class="text-secondary text-uppercase mb-4">My Account</h5>
              <div class="d-flex flex-column justify-content-start">
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Home</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Our Shop</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Shop Detail</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Shopping Cart</a
                >
                <a class="text-secondary mb-2" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Checkout</a
                >
                <a class="text-secondary" href="#"
                  ><i class="fa fa-angle-right mr-2"></i>Contact Us</a
                >
              </div>
            </div>
            <div class="col-md-4 mb-5">
              <h5 class="text-secondary text-uppercase mb-4">Newsletter</h5>
              <p>Duo stet tempor ipsum sit amet magna ipsum tempor est</p>
              <form action="">
                <div class="input-group">
                  <input
                    type="text"
                    class="form-control"
                    placeholder="Your Email Address"
                  />
                  <div class="input-group-append">
                    <button class="btn btn-warning">Sign Up</button>
                  </div>
                </div>
              </form>
              <h6 class="text-secondary text-uppercase mt-4 mb-3">Follow Us</h6>
              <div class="d-flex">
                <a
                  style="margin-right: 10px"
                  class="btn btn-warning btn-square mr-2"
                  href="#"
                  ><i class="fab fa-twitter"></i
                ></a>
                <a
                  style="margin-right: 10px"
                  class="btn btn-warning btn-square mr-2"
                  href="#"
                  ><i class="fab fa-facebook-f"></i
                ></a>
                <a
                  style="margin-right: 10px"
                  class="btn btn-warning btn-square mr-2"
                  href="#"
                  ><i class="fab fa-linkedin-in"></i
                ></a>
                <a
                  style="margin-right: 10px"
                  class="btn btn-warning btn-square"
                  href="#"
                  ><i class="fab fa-instagram"></i
                ></a>
              </div>
              <hr />
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer End -->

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="lib/easing/easing.min.js"></script> -->
    <!-- <script src="lib/owlcarousel/owl.carousel.min.js"></script> -->

    <!-- Contact Javascript File -->
    <!-- <script src="mail/jqBootstrapValidation.min.js"></script> -->
    <!-- <script src="mail/contact.js"></script> -->

    <!-- Template Javascript -->
    <!-- <script src="js/main.js"></script> -->

    <!-- Template Javascript -->
  </body>
</html>
