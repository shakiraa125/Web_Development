<?php
     include('config.php');
      // Check if the request is coming with the expected data
      if (isset($_POST['productId']) && $_POST['userId']) {
       

        // Get the values
        $productId = $_POST['productId'];
        session_start();
        $email = $_SESSION['user'];

        // // Prepare the SQL query
        $query = "INSERT INTO cart (bookid,email, quantity,status) VALUES ('$productId','$email', 1,'cart')";

        // // Execute the query
        $result = mysqli_query($con, $query);

        // Check if the insert was successful
        if ($result) {
            // Product added to the cart table successfully
            echo json_encode(['status' => 'success', 'message' =>      'Product added to the cart.']);
        } else {
            // Error in the insert operation
            echo json_encode(['status' => 'error', 'message' => 'Failed to add product to the cart.']);
        }
    } else {
        // Return an error message if data is missing
        echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
    }

?>