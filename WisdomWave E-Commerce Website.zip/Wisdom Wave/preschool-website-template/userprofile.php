<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Big Cart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="Free HTML Templates" name="keywords" />
    <meta content="Free HTML Templates" name="description" />

    <!-- Favicon -->
    <!-- <link href="img/favicon.ico" rel="icon" /> -->

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap"
      rel="stylesheet"
    />

    <!-- Font Awesome -->
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
      rel="stylesheet"
    />

    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
      integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65"
      crossorigin="anonymous"
    />

    <?php
    
     include('config.php');
     session_start();
    $email=$_SESSION['user'];
     $sql="SELECT * FROM address where emailid='$email'";
     //read data from mysql
     $q=mysqli_query($con,$sql);
     ?>
  </head>

  <body>

  <?php
     include 'header1.php';
    
     if ($q->num_rows > 0)  
     { 
         
         while($row = $q->fetch_assoc()) 
         { 

                       

         
                        
                         $_SESSION['name']=$row["name"] ?? "";
                          $phone=$row["phoneno"] ?? "";
                          $home=$row["home"] ?? "";
                          $street=$row["street"] ?? "";
                          $district=$row["district"] ?? "";
                          $city=$row["city"] ?? "";
                          $state=$row["state"] ?? "";
                          $country=$row["country"] ?? "";
                          $pincode=$row["pincode"] ?? "";
                          $name= $_SESSION['name'] ?? "";
                       
                     
                                     
                                     
                        
                      }}      
?>
                     
      <form action="billing_address.php"
            <div class="col-lg-9 col-md-9">
                  <div class="row">
                    <!-- User  -->
                    <div class="col-md-3 border-right">
                        
                    </div>
                    <div class="col-md-5 border-right">
                        <div class="p-3 py-5">
                            <div class="row mt-2">
                                <div class="col-md-6">
                                  <label class="labels">Name</label>
                                  <input 
                                  id="name"
                                  name="name"
                                    type="text" 
                                    disabled
                                    class="form-control" 
                                    placeholder="first name" 
                                    value="<?php echo $name;?>">
                                </div>

                                <div class="col-md-6">
                                  <label class="labels">Email</label>
                                  <input 
                                    type="text" 
                                    disabled
                                    class="form-control" 
                                    value="<?php echo $email;?>"
                                    placeholder="email">
                                </div>
                            </div>
                            
                            <div class="row mt-3">
                                <div class="col-md-6">
                                  <label class="labels">phone</label>
                                  <input 
                                    type="text" 
                                    disabled
                                    class="form-control" 
                                    placeholder="phone" 
                                    
                                    value="<?php
                                       echo $phone ;?>">
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="p-3 py-5">
                          <h6>Address</h6>
                          <div class="row mt-3">

                            <div class="mt-3 col-md-12">
                              <label class="labels">home</label>
                              <input 
                                disabled
                                type="text" 
                                class="form-control" 
                                placeholder="enter your home name or flat number" 
                                id="home"
                                value="<?php echo $home;?>">
                            </div>

                            <div class="mt-3 col-md-12">
                              <label class="labels">Street</label>
                              <input 
                                disabled
                                type="text" 
                                class="form-control" 
                                placeholder="enter your Street name" 
                                id="street"
                                value="<?php echo $street;?>">
                            </div>

                            <div class="mt-3 col-md-12">
                              <label class="labels">District</label>
                              <input 
                                disabled
                                type="text" 
                                class="form-control" 
                                id="district"
                                placeholder="enter your district" 
                                value="<?php echo $district;?>">
                            </div>

                            <div class="mt-3 col-md-12">
                              <label class="labels">City</label>
                              <input 
                                disabled
                                type="text" 
                                class="form-control" 
                                id="city"
                                placeholder="enter your city" 
                                value="<?php echo $city;?>">
                            </div>

                            <div class="mt-3 col-md-12">
                              <label class="labels">State</label>
                              <input 
                                disabled
                                type="text" 
                                class="form-control" 
                                id="state"
                                placeholder="enter your state" 
                                value="<?php echo $state;?>">
                            </div>

                            <div class="mt-3 col-md-12">
                              <label class="labels">Country</label>
                              <input 
                                disabled
                                type="text" 
                                class="form-control" 
                                id="state"
                                alt=""
                                placeholder="enter your state" 
                                value="<?php echo $country;?>">
                            </div>

                            <div class="mt-3 col-md-12"><label class="labels">Zip</label>
                              <input
                                disabled 
                                type="text" 
                                class="form-control" 
                                id="zip"
                                placeholder="enter your zip code" 
                                value="<?php echo $pincode;?>">
                            </div>
                            <div class="w-100"></div>
							<button type="submit">Edit profile</button>
                    </form>
								</div>
                          </div>
                        
                    </div>
                </div>
            </div>
            
           
            <!-- User Details page -->
      </div>
    
  </div>
  <?php
         
 if (isset($_POST['submit'])) {
  echo "hai";

/*$_SESSION['email']=$name;*/

header('Location: billing_address.php');
echo "<script>location.href = 'billing_address.php';</script>";
}
?>
 
  <!-- /Admin main condainer end -->
  </body>
</html>
