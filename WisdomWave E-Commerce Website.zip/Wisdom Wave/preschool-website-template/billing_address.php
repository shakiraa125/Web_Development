<!DOCTYPE html>
<html lang="en">

<head>
	<title>Vegefoods - Free Bootstrap 4 Template by Colorlib</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/ionicons.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">


	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css">
	<?php
	
	session_start();
	require('config.php');
	?>
</head>

<body class="goto-here">


	<?php
		include('header1.php');
	
	
		$email = $_SESSION['user'];
		//$total_amount = $_SESSION['totalcost'];
		//echo $total_amount;
		$name=$_SESSION['name'];
	$allstates = array(
		"Andhra Pradesh" => "AP",
		"Arunachal Pradesh" => "AR",
		"Assam" => "AS",
		"Bihar" => "BR",
		"Chhattisgarh" => "CG",
		"Goa" => "GA",
		"Gujarat" => "GJ",
		"Haryana" => "HR",
		"Himachal Pradesh" => "HP",
		"Jharkhand" => "JH",
		"Karnataka" => "KA",
		"Kerala" => "KL",
		"Madhya Pradesh" => "MP",
		"Maharashtra" => "MH",
		"Manipur" => "MN",
		"Meghalaya" => "ML",
		"Mizoram" => "MZ",
		"Nagaland" => "NL",
		"Odisha" => "OD",
		"Punjab" => "PB",
		"Rajasthan" => "RJ",
		"Sikkim" => "SK",
		"Tamil Nadu" => "TN",
		"Telangana" => "TG",
		"Tripura" => "TR",
		"Uttar Pradesh" => "UP",
		"Uttarakhand" => "UK",
		"West Bengal" => "WB",
		"Andaman and Nicobar Islands" => "AN",
		"Chandigarh" => "CH",
		"Dadra and Nagar Haveli and Daman and Diu" => "DN",
		"Delhi" => "DL",
		"Lakshadweep" => "LD",
		"Puducherry" => "PY"
	);
	$q = mysqli_query($con, "select * from address ");


	?>
	<div class="container">
		<div class="row no-gutters slider-text align-items-left justify-content-left">
			<div class="col-md-9 ftco-animate text-left">
				<p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home</a></span> <span><a href="">Billing details</a></span></p>
				<h1 class="mb-0 bread">Checkout</h1>
			</div>
		</div>
	</div>

	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-xl-7 ftco-animate">
					<form action="#" method="post" class="billing-form">
						<h3 class="mb-4 billing-heading">Billing Details</h3>
						<?php
						if ($q->num_rows > 0) {

							while ($row = $q->fetch_assoc()) {

								
								//$email =  $_SESSION['user'];
								$state = $row["state"];
                                //$name = $row["name"];
								$city = $row["city"];
								$postcode = $row["pincode"];
								$phone = $row["phoneno"];
								$street = $row["street"];
								$home = $row["home"];
								$district = $row["district"];
								$country = $row["country"];
								//$email = $row["email"];
								//$address = $row["address"];

							}
						?>

								
                                    <div class="row align-items-end">
									<div class="col-md-12">
										<div class="form-group">
											<label for="firstname">Name</label>
											<input type="text" value="<?php echo $name;?>" name="n" id="n" class="form-control" placeholder="">
										</div>
									</div>
                                    <div class="row align-items-end">
									<div class="col-md-12">
										<div class="form-group">
											<label for="firstname">email</label>
											<input type="text" value="<?php echo $email; ?>" name="name" class="form-control" placeholder="">
										</div>
									</div>

									<div class="w-100"></div>
									<div class="col-md-12">
										<div class="form-group">
											<label for="country">State</label>
											<div class="select-wrap">
												<div class="icon"><span class="ion-ios-arrow-down"></span></div>
												<select name="state" id="state" class="form-control">


													<?php
													foreach ($allstates as $value => $label) {
														echo "<option value=\"$label\"";
														echo $label == $state ? " selected" : "";
														echo ">$value</option>";
														echo "<script>console.log($value)</script>";
													}

													?>

												</select>
											</div>
										</div>
									</div>
									<div class="w-100"></div>
									<div class="col-md-12">
										<div class="form-group">
											<label for="streetaddress">home</label>
											<input type="text" name="home" value="<?php echo $home ?>" class="form-control" placeholder="House number and street name">
										</div>
									</div>

								    <div class="w-100"></div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="towncity">City</label>
											<input type="text" name="city" value="<?php echo $city ?>" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="postcodezip">Pincode*</label>
											<input type="number" name="postcode" value="<?php echo $postcode ?>" class="form-control" placeholder="">
										</div>
									</div>
									<div class="w-100"></div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="phone">Phone</label>
											<input type="number" name="phone" value="<?php echo $phone ?>" class="form-control" placeholder="">
										</div>
									</div>
									<div class="w-100"></div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="towncity">district</label>
											<input type="text" name="district" value="<?php echo $district ?>" class="form-control" placeholder="">
										</div>
									</div>
									<div class="w-100"></div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="towncity">country</label>
											<input type="text" name="country" value="<?php echo $country ?>" class="form-control" placeholder="">
										</div>
									</div>
									<div class="w-100"></div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="towncity">street</label>
											<input type="text" name="street" value="<?php echo $street ?>" class="form-control" placeholder="">
										</div>
									</div>
									
									
							<?php
							}
	
							?>
							<div class="w-100"></div>
							<button type="submit">Update</button>
								</div>
					</form><!-- END -->
				
	</section> <!-- .section -->


	<?php

	include('footer.php');
	?>


	
			</script>

</body>
<?php

//updating billing_details table if any of the field changes and click sava button
if (isset($_POST['n']) || isset($_POST['state']) || isset($_POST['address']) || isset($_POST['city']) || isset($_POST['phone']) || isset($_POST['email']) || isset($_POST['postcode'])) {

	//$name = $_POST['name'];
	$state = $_POST['state'];
    $name = $_POST['n'];
	$city = $_POST['city'];
	$postcode = $_POST['postcode'];
	$phone = $_POST['phone'];
	$email = $_SESSION['user'];
	$home = $_POST['home'];
		$ql = mysqli_query($con, "UPDATE address
		SET  
			emailid = '$email', 
			name = '$name', 
			state = '$state', 
			city = '$city', 
			pincode = '$postcode', 
			phoneno = '$phone',  
			home = '$home'
		WHERE emailid='$email'");
				  header('Location: userprofile');
				  echo "<script>location.href = 'userprofile.php';</script>";
		  }   
	
//update register table
 //  $ql = mysqli_query($con, "UPDATE register SET name='$name' WHERE userEmail='$email'");



?>

	<!-- loader -->
	<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
			<circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
			<circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" />
		</svg></div>


	<script src="js/jquery.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
	<script src="js/google-map.js"></script>
	<script src="js/main.js"></script>

</body>
</html>