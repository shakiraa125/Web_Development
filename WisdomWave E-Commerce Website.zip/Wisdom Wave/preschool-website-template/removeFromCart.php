<?php
     include('config.php');
      // Check if the request is coming with the expected data
      if (isset($_POST['productId']) ) {
        
        // Get the values
        $id = $_POST['productId'];
       
        // Start session
        session_start();

        // Retrieve email from the session
        $email = $_SESSION['user'];


        // // Prepare the SQL query
      //  $query = "delete from cart where bookid='$id' and email='$email'";
        $query = "delete from cart where id=$id and status='cart' and email='$email'";

        // // Execute the query
        $result = mysqli_query($con, $query);

        if ($result) {
            // Product added to the cart table successfully
            echo json_encode(['status' => 'success', 'message' =>      'Product removed to the cart.']);
        } else {
            // Error in the insert operation
            echo json_encode(['status' => 'error', 'message' => 'Failed to remove product to the cart.']);
        }

        // Check if the insert was successful
       /* if ($result) {
            // Product added to the cart table successfully
            echo json_encode(['status' => 'success', 'message' =>      'Product added to the cart.']);
        } else {
            // Error in the insert operation
            echo json_encode(['status' => 'error', 'message' => 'Failed to add product to the cart.']);
        }
    } else {
        // Return an error message if data is missing
        echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
    }*/
      }
?>